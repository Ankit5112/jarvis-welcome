# jarvis-welcome 
#### Beautify your Termux App With a warm and jarvis welcome

## [+] Installation & Usage
```
apt update
apt install git -y
pkg install mpv -y
git clone https://github.com/Ankit/jarvis-welcome.git
cd jarvis-welcome
chmod +x *
sh install.sh
exit
```
### or use Single Command
```
apt update && apt install git -y && pkg install mpv && git clone  https://github.com/Ankit/jarvis-welcome.git && cd jarvis-welcome && chmod +x * && ./install.sh
```
## [+]How to remove 
```
cd jarvis-welcome

bash rvt.sh
