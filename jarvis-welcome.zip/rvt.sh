pip install bs4
cd
cd ..
cd usr/etc
rm bash.bashrc
cd $HOME/jarvis-welcome/Revert
mv bash.bashrc $PREFIC/etc
python $HOME/jarvis-welcome/Revert/Thanks.py
